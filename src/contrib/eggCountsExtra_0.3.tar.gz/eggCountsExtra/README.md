# eggCountsExtra
Add-ons for eggCounts Package, the main package [`eggCounts`](https://CRAN.R-project.org/package=eggCounts) is available on CRAN.



## Installation

You can install `eggCountsExtra` from GitHub. 

```r
devtools::install_github("CraigWangatCH/eggCountsExtra")
```

